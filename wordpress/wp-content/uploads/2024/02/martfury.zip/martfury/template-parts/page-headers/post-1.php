<div class="single-post-header text-center layout-1">
	<div class="container">
		<div class="page-content">
			<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
			<div class="entry-metas">
				<?php martfury_posted_on( true, true ); ?>
			</div>
		</div>
	</div>
	<div class="featured-image"></div>
</div>